/**
 * Created by p5030 on 2017/5/25.
 */
//簡化讀取obj File的function
//scene: 你所建造好的場景
//objPath : obj檔案的位置
//obj: obj的檔名
//position:{ 算是物件
// x:  x座標的位置
// y:  y座標的位置
// z:  z座標的位置
//}
/*
size :{ //控制大小的物件
 x: x向量的大小
 y: y向量的大小
 z: z向量的大小
}
*/
/*
 angle :{ //控制角度的物件
 x: x向量的角度
 y: y向量的角度
 z: z向量的角度
 }
 */
function loadObj(scene,objname,objPath,obj,position,size,angle){ //position is { x: x , y: y  ,z:z}
    var loader = new BABYLON.AssetsManager(scene);
    BABYLON.OBJFileLoader.OPTIMIZE_WITH_UV = true;
    var pos = function(t) {
        t.loadedMeshes.forEach(function(m) {
            m.position.x =position.x;
            m.position.y = position.y;
            m.position.z = position.z;
            m.scaling.x = size.x;
            m.scaling.y = size.y;
            m.scaling.z = size.z;
            m.rotation.x = angle.x;
            m.rotation.y =angle.y;
            m.rotation.z = angle.z;
        });
    };
    var object = loader.addMeshTask(objname, "", objPath, obj);
   // console.log(object)
    //console.log("fuck")
    //console.log(object)

    object.onSuccess = pos;
    loader.load();
    //console.log(object.loadedMeshes)
    return {"scene":scene,"object":object};
}
